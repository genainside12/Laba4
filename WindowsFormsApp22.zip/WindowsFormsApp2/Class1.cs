﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class Class1
    {
        MySqlConnection connection = new MySqlConnection("server = mysql.tarasov-sasha.myjino.ru;port = 3306;username = 047010312_q1 ;password = QAZ97wsx64;database = tarasov-sasha_q1");
        public void openCon()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();
        }
        public void closeCon()
        {
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
        }

        public MySqlConnection getCon()
        {
            return connection;
        }

    }
}
