﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp2
{
    public partial class Form5 : Form
    {
        int iz, v;
        public Form5()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            iz = 0;
            label5.Text = "Миллиметр";
            //izmm.Checked = false;
            izsm.Checked = false;
            izdc.Checked = false;
            izm.Checked = false;
            izkm.Checked = false;
            izgr.Checked = false;
            izkg.Checked = false;
            izct.Checked = false;
            izt.Checked = false;
        }

        private void izsm_CheckedChanged(object sender, EventArgs e)
        {
            iz = 1;
            label5.Text = "Сантиметры";
            izmm.Checked = false;
            //izsm.Checked = false;
            izdc.Checked = false;
            izm.Checked = false;
            izkm.Checked = false;
            izgr.Checked = false;
            izkg.Checked = false;
            izct.Checked = false;
            izt.Checked = false;
        }

        private void izdc_CheckedChanged(object sender, EventArgs e)
        {
            iz = 2;
            label5.Text = "Дециметры";
            izmm.Checked = false;
            izsm.Checked = false;
            //izdc.Checked = false;
            izm.Checked = false;
            izkm.Checked = false;
            izgr.Checked = false;
            izkg.Checked = false;
            izct.Checked = false;
            izt.Checked = false;
        }

        private void izm_CheckedChanged(object sender, EventArgs e)
        {
            iz = 3;
            label5.Text = "Метры";
            izmm.Checked = false;
            izsm.Checked = false;
            izdc.Checked = false;
            //izm.Checked = false;
            izkm.Checked = false;
            izgr.Checked = false;
            izkg.Checked = false;
            izct.Checked = false;
            izt.Checked = false;
        }

        private void izkm_CheckedChanged(object sender, EventArgs e)
        {
            iz = 4;
            label5.Text = "Километры";
            izmm.Checked = false;
            izsm.Checked = false;
            izdc.Checked = false;
            izm.Checked = false;
            //izkm.Checked = false;
            izgr.Checked = false;
            izkg.Checked = false;
            izct.Checked = false;
            izt.Checked = false;
        }

        private void izgr_CheckedChanged(object sender, EventArgs e)
        {
            iz = 5;
            label5.Text = "Граммы";
            izmm.Checked = false;
            izsm.Checked = false;
            izdc.Checked = false;
            izm.Checked = false;
            izkm.Checked = false;
            //izgr.Checked = false;
            izkg.Checked = false;
            izct.Checked = false;
            izt.Checked = false;
        }

        private void izkg_CheckedChanged(object sender, EventArgs e)
        {
            iz = 6;
            label5.Text = "Килограммы";
            izmm.Checked = false;
            izsm.Checked = false;
            izdc.Checked = false;
            izm.Checked = false;
            izkm.Checked = false;
            izgr.Checked = false;
            //izkg.Checked = false;
            izct.Checked = false;
            izt.Checked = false;
        }

        private void izct_CheckedChanged(object sender, EventArgs e)
        {
            iz = 7;
            label5.Text = "Центнеры";
            izmm.Checked = false;
            izsm.Checked = false;
            izdc.Checked = false;
            izm.Checked = false;
            izkm.Checked = false;
            izgr.Checked = false;
            izkg.Checked = false;
            //izct.Checked = false;
            izt.Checked = false;
        }

        private void izt_CheckedChanged(object sender, EventArgs e)
        {
            iz = 8;
            label5.Text = "Тонны";
            izmm.Checked = false;
            izsm.Checked = false;
            izdc.Checked = false;
            izm.Checked = false;
            izkm.Checked = false;
            izgr.Checked = false;
            izkg.Checked = false;
            izct.Checked = false;
            //izt.Checked = false;
        }

        private void vmm_CheckedChanged(object sender, EventArgs e)
        {
            v = 0;
            label6.Text = "Миллиметры";
            //vmm.Checked = false;
            vsm.Checked = false;
            vdc.Checked = false;
            vm.Checked = false;
            vkm.Checked = false;
            vgr.Checked = false;
            vkg.Checked = false;
            vct.Checked = false;
            vt.Checked = false;
        }

        private void vsm_CheckedChanged(object sender, EventArgs e)
        {
            v = 1;
            label6.Text = "Сантиметры";
            vmm.Checked = false;
            //vsm.Checked = false;
            vdc.Checked = false;
            vm.Checked = false;
            vkm.Checked = false;
            vgr.Checked = false;
            vkg.Checked = false;
            vct.Checked = false;
            vt.Checked = false;
        }

        private void vdc_CheckedChanged(object sender, EventArgs e)
        {
            v = 2;
            label6.Text = "Дециметры";
            vmm.Checked = false;
            vsm.Checked = false;
            //vdc.Checked = false;
            vm.Checked = false;
            vkm.Checked = false;
            vgr.Checked = false;
            vkg.Checked = false;
            vct.Checked = false;
            vt.Checked = false;
        }

        private void vm_CheckedChanged(object sender, EventArgs e)
        {
            v = 3;
            label6.Text = "Метры";
            vmm.Checked = false;
            vsm.Checked = false;
            vdc.Checked = false;
            //vm.Checked = false;
            vkm.Checked = false;
            vgr.Checked = false;
            vkg.Checked = false;
            vct.Checked = false;
            vt.Checked = false;
        }

        private void vkm_CheckedChanged(object sender, EventArgs e)
        {
            v = 4;
            label6.Text = "Километры";
            vmm.Checked = false;
            vsm.Checked = false;
            vdc.Checked = false;
            vm.Checked = false;
            //vkm.Checked = false;
            vgr.Checked = false;
            vkg.Checked = false;
            vct.Checked = false;
            vt.Checked = false;
        }

        private void vgr_CheckedChanged(object sender, EventArgs e)
        {
            v = 5;
            label6.Text = "Граммы";
            vmm.Checked = false;
            vsm.Checked = false;
            vdc.Checked = false;
            vm.Checked = false;
            vkm.Checked = false;
            //vgr.Checked = false;
            vkg.Checked = false;
            vct.Checked = false;
            vt.Checked = false;
        }

        private void vkg_CheckedChanged(object sender, EventArgs e)
        {
            v = 6;
            label6.Text = "Килограммы";
            vmm.Checked = false;
            vsm.Checked = false;
            vdc.Checked = false;
            vm.Checked = false;
            vkm.Checked = false;
            vgr.Checked = false;
            //vkg.Checked = false;
            vct.Checked = false;
            vt.Checked = false;
        }

        private void vct_CheckedChanged(object sender, EventArgs e)
        {
            v = 7;
            label6.Text = "Центнеры";
            vmm.Checked = false;
            vsm.Checked = false;
            vdc.Checked = false;
            vm.Checked = false;
            vkm.Checked = false;
            vgr.Checked = false;
            vkg.Checked = false;
            //vct.Checked = false;
            vt.Checked = false;
        }

        private void vt_CheckedChanged(object sender, EventArgs e)
        {
            v = 8;
            label6.Text = "Тонны";
            vmm.Checked = false;
            vsm.Checked = false;
            vdc.Checked = false;
            vm.Checked = false;
            vkm.Checked = false;
            vgr.Checked = false;
            vkg.Checked = false;
            vct.Checked = false;
            //vt.Checked = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server = mysql.tarasov-sasha.myjino.ru ;port = 3306; username = 047010312_q1 ;password = QAZ97wsx64; database = tarasov-sasha_q1");
            connection.Open();

            MySqlCommand command = new MySqlCommand("UPDATE `bdlab2uch` SET `kolperevod` = `kolperevod` + 1", connection);
            command.ExecuteNonQuery();

            float a;
            a = Convert.ToInt32(textBox1.Text);
            if (iz > -1 && iz < 5 && v > 4 && v < 9)
            {
                textBox2.Text = "Нельзя!!!";
            }
            if (v > -1 && v < 5 && iz > 4 && iz < 9)
            {
                textBox2.Text = "Нельзя!!!";
            }
            if (iz == 0 && v == 0)
            {
                textBox2.Text = Convert.ToString(a);
            }
            if (iz == 0 && v == 1)
            {
                textBox2.Text = Convert.ToString(a / 10);
            }
            if (iz == 0 && v == 2)
            {
                textBox2.Text = Convert.ToString(a / 100);
            }
            if (iz == 0 && v == 3)
            {
                textBox2.Text = Convert.ToString(a / 1000);
            }
            if (iz == 0 && v == 4)
            {
                textBox2.Text = Convert.ToString(a / 1000000);
            }
            if (iz == 1 && v == 0)
            {
                textBox2.Text = Convert.ToString(a * 10);
            }
            if (iz == 1 && v == 1)
            {
                textBox2.Text = Convert.ToString(a);
            }
            if (iz == 1 && v == 2)
            {
                textBox2.Text = Convert.ToString(a / 10);
            }
            if (iz == 1 && v == 3)
            {
                textBox2.Text = Convert.ToString(a / 100);
            }
            if (iz == 1 && v == 4)
            {
                textBox2.Text = Convert.ToString(a / 1000);
            }
            if (iz == 2 && v == 0)
            {
                textBox2.Text = Convert.ToString(a * 100);
            }
            if (iz == 2 && v == 1)
            {
                textBox2.Text = Convert.ToString(a * 10);
            }
            if (iz == 2 && v == 2)
            {
                textBox2.Text = Convert.ToString(a);
            }
            if (iz == 2 && v == 3)
            {
                textBox2.Text = Convert.ToString(a / 10);
            }
            if (iz == 2 && v == 4)
            {
                textBox2.Text = Convert.ToString(a / 100);
            }
            if (iz == 3 && v == 0)
            {
                textBox2.Text = Convert.ToString(a * 1000);
            }
            if (iz == 3 && v == 1)
            {
                textBox2.Text = Convert.ToString(a * 100);
            }
            if (iz == 3 && v == 2)
            {
                textBox2.Text = Convert.ToString(a * 10);
            }
            if (iz == 3 && v == 3)
            {
                textBox2.Text = Convert.ToString(a);
            }
            if (iz == 3 && v == 4)
            {
                textBox2.Text = Convert.ToString(a / 10);
            }
            if (iz == 4 && v == 0)
            {
                textBox2.Text = Convert.ToString(a * 10000);
            }
            if (iz == 4 && v == 1)
            {
                textBox2.Text = Convert.ToString(a * 1000);
            }
            if (iz == 4 && v == 2)
            {
                textBox2.Text = Convert.ToString(a * 100);
            }
            if (iz == 4 && v == 3)
            {
                textBox2.Text = Convert.ToString(a * 10);
            }
            if (iz == 4 && v == 4)
            {
                textBox2.Text = Convert.ToString(a);
            }
            if (iz == 5 && v == 5)
            {
                textBox2.Text = Convert.ToString(a);
            }
            if (iz == 5 && v == 6)
            {
                textBox2.Text = Convert.ToString(a / 1000);
            }
            if (iz == 5 && v == 7)
            {
                textBox2.Text = Convert.ToString(a / 100000);
            }
            if (iz == 5 && v == 8)
            {
                textBox2.Text = Convert.ToString(a / 1000000);
            }
            if (iz == 6 && v == 5)
            {
                textBox2.Text = Convert.ToString(a * 1000);
            }
            if (iz == 6 && v == 6)
            {
                textBox2.Text = Convert.ToString(a);
            }
            if (iz == 6 && v == 7)
            {
                textBox2.Text = Convert.ToString(a / 100);
            }
            if (iz == 6 && v == 8)
            {
                textBox2.Text = Convert.ToString(a / 1000);
            }
            if (iz == 7 && v == 5)
            {
                textBox2.Text = Convert.ToString(a * 100000);
            }
            if (iz == 7 && v == 6)
            {
                textBox2.Text = Convert.ToString(a * 100);
            }
            if (iz == 7 && v == 7)
            {
                textBox2.Text = Convert.ToString(a);
            }
            if (iz == 7 && v == 8)
            {
                textBox2.Text = Convert.ToString(a / 10);
            }
            if (iz == 8 && v == 5)
            {
                textBox2.Text = Convert.ToString(a * 1000000);
            }
            if (iz == 8 && v == 6)
            {
                textBox2.Text = Convert.ToString(a * 1000);
            }
            if (iz == 8 && v == 7)
            {
                textBox2.Text = Convert.ToString(a * 10);
            }
            if (iz == 8 && v == 8)
            {
                textBox2.Text = Convert.ToString(a);
            }
        }
    }
}
