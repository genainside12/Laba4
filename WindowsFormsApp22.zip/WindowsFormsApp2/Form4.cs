﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp2
{
    public partial class Form4 : Form
    {
        private MySqlConnection mySqlConnection = null;
        private MySqlDataAdapter adapter = null;
        private DataTable table = null;

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection("server = mysql.tarasov-sasha.myjino.ru ;port = 3306; username = 047010312_q1 ;password = QAZ97wsx64; database = tarasov-sasha_q1");
            connection.Open();
            MySqlCommand command = new MySqlCommand("SELECT reshkvad FROM bdlab2uch ", connection);
            string name = command.ExecuteScalar().ToString();
            textBox1.Text = name;
            command = new MySqlCommand("SELECT reshkub FROM bdlab2uch ", connection);
            name = command.ExecuteScalar().ToString();
            textBox2.Text = name;
            textBox3.Text = Convert.ToString(Convert.ToInt32(textBox1.Text) + Convert.ToInt32(textBox2.Text));
            command = new MySqlCommand("SELECT count(*) FROM bdlab2 ", connection);
            name = command.ExecuteScalar().ToString();
            textBox4.Text = name;
            command = new MySqlCommand("SELECT koledv FROM bdlab2uch ", connection);
            name = command.ExecuteScalar().ToString();
            textBox5.Text = name;
            command = new MySqlCommand("SELECT kolediz FROM bdlab2uch ", connection);
            name = command.ExecuteScalar().ToString();
            textBox6.Text = name;
            command = new MySqlCommand("SELECT kolperevod FROM bdlab2uch ", connection);
            name = command.ExecuteScalar().ToString();
            textBox7.Text = name;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
