﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp2


{
    public partial class Form2 : Form
    {
        public static double ATanh(double x)
        {
            return (Math.Log(1 + x) - Math.Log(1 - x)) / 2;
        }
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a, b, c;
            double D;
            double x1, x2;

            MySqlConnection connection = new MySqlConnection("server = mysql.tarasov-sasha.myjino.ru ;port = 3306; username = 047010312_q1 ;password = QAZ97wsx64; database = tarasov-sasha_q1");
            connection.Open();

            if (radioButton1.Checked == true)
            {
                MySqlCommand command = new MySqlCommand("UPDATE `bdlab2uch` SET `reshkvad` = `reshkvad` + 1", connection);
                command.ExecuteNonQuery();

                a = Convert.ToInt32(textBox1.Text);
                b = Convert.ToInt32(textBox2.Text);
                c = Convert.ToInt32(textBox3.Text);
                D = b * b - 4 * a * c; // 16 - 24 -8
                if (D < 0)
                {
                    textBox5.Text = "Корней нет";
                }
                else if (D == 0)
                {
                    x1 = -b / (2 * a);
                    x1 = Math.Round(x1,2);
                }
                else if (D > 0)
                {
                    x1 = Math.Round((-b + Math.Sqrt(D)) / (2 * a), 2);
                    x2 = Math.Round((-b - Math.Sqrt(D)) / (2 * a), 2);
                    textBox5.Text = "Решение x1 = " + Convert.ToString(Math.Round(x1, 2)) + "; x2 = " + Convert.ToString(Math.Round(x2, 2));
                }
            }
            else if (radioButton2.Checked == true) {
                double R,Q,S;
                float P=3.14f;
                MySqlCommand command = new MySqlCommand("UPDATE `bdlab2uch` SET `reshkub` = `reshkub` + 1", connection);
                command.ExecuteNonQuery();

                a = Convert.ToInt32(textBox1.Text);
                b = Convert.ToInt32(textBox2.Text);
                c = Convert.ToInt32(textBox3.Text);
                Q = (a * a - 3 * b) / 9;
                R = (2 * Math.Pow(a, -3) - 9 * a * b + 27 * c) / 54;
                S = Math.Pow(Q, 3) - Math.Pow(R, 2);
                double x3;

                if (S > 0)
                {
                    double F;
                    F = Math.Acos(R / Math.Pow(Q, 3 / 2)) / 3;
                    x1 = -2 * Math.Pow(Q, 1 / 2) + Math.Cos(F) - a / 3;
                    x2 = -1 * Math.Pow(Q, 1 / 2) + Math.Cos(F + (2 * P/3)) - a / 3;
                    x3 = -1 * Math.Pow(Q, 1 / 2) + Math.Cos(F - (2 * P / 3)) - a / 3;
                    textBox5.Text = "Решение x1 = " + Convert.ToString(Math.Round(x1, 2)) + "; x2 = " + Convert.ToString(Math.Round(x2, 2)) + "; x3 = " + Convert.ToString(Math.Round(x3, 2));
                }
                else if (S < 0)
                {
                    double F;
                    F = ATanh(Math.Abs(R)/ Math.Pow(Math.Abs(Q),3/2))/3;
                    x1 = -2 * Math.Sign(R) * Math.Pow(Math.Abs(Q), 1 / 2) * Math.Cosh(F) - a / 3; 
                    textBox5.Text = "Решение x1 = " + Convert.ToString(Math.Round(x1, 2)) + "остальные минимые корни";
                }
                else if (S == 0) {
                    x1 = -2 * Math.Pow(R, 1 / 3) - a / 3;
                    x2 = Math.Pow(R, 1 / 3) - a / 3;
                    x3 = x2;
                    textBox5.Text = "Решение x1 = " + Convert.ToString(Math.Round(x1, 2)) + "; x2 = " + Convert.ToString(Math.Round(x2, 2)) + "; x3 = " + Convert.ToString(Math.Round(x3, 2));
                }
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
