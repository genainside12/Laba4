﻿
namespace WindowsFormsApp2
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.izmm = new System.Windows.Forms.RadioButton();
            this.izsm = new System.Windows.Forms.RadioButton();
            this.izdc = new System.Windows.Forms.RadioButton();
            this.izm = new System.Windows.Forms.RadioButton();
            this.izkm = new System.Windows.Forms.RadioButton();
            this.vkm = new System.Windows.Forms.RadioButton();
            this.vm = new System.Windows.Forms.RadioButton();
            this.vdc = new System.Windows.Forms.RadioButton();
            this.vsm = new System.Windows.Forms.RadioButton();
            this.vmm = new System.Windows.Forms.RadioButton();
            this.izgr = new System.Windows.Forms.RadioButton();
            this.izkg = new System.Windows.Forms.RadioButton();
            this.izct = new System.Windows.Forms.RadioButton();
            this.izt = new System.Windows.Forms.RadioButton();
            this.vt = new System.Windows.Forms.RadioButton();
            this.vct = new System.Windows.Forms.RadioButton();
            this.vkg = new System.Windows.Forms.RadioButton();
            this.vgr = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // izmm
            // 
            this.izmm.Appearance = System.Windows.Forms.Appearance.Button;
            this.izmm.AutoSize = true;
            this.izmm.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.izmm.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.izmm.Location = new System.Drawing.Point(23, 40);
            this.izmm.Name = "izmm";
            this.izmm.Size = new System.Drawing.Size(75, 23);
            this.izmm.TabIndex = 0;
            this.izmm.Text = "Миллиметр";
            this.izmm.UseVisualStyleBackColor = false;
            this.izmm.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // izsm
            // 
            this.izsm.Appearance = System.Windows.Forms.Appearance.Button;
            this.izsm.AutoSize = true;
            this.izsm.Location = new System.Drawing.Point(23, 63);
            this.izsm.Name = "izsm";
            this.izsm.Size = new System.Drawing.Size(72, 23);
            this.izsm.TabIndex = 1;
            this.izsm.Text = "Сантиметр";
            this.izsm.UseVisualStyleBackColor = true;
            this.izsm.CheckedChanged += new System.EventHandler(this.izsm_CheckedChanged);
            // 
            // izdc
            // 
            this.izdc.Appearance = System.Windows.Forms.Appearance.Button;
            this.izdc.AutoSize = true;
            this.izdc.Location = new System.Drawing.Point(23, 86);
            this.izdc.Name = "izdc";
            this.izdc.Size = new System.Drawing.Size(69, 23);
            this.izdc.TabIndex = 2;
            this.izdc.Text = "Дециметр";
            this.izdc.UseVisualStyleBackColor = true;
            this.izdc.CheckedChanged += new System.EventHandler(this.izdc_CheckedChanged);
            // 
            // izm
            // 
            this.izm.Appearance = System.Windows.Forms.Appearance.Button;
            this.izm.AutoSize = true;
            this.izm.Location = new System.Drawing.Point(23, 109);
            this.izm.Name = "izm";
            this.izm.Size = new System.Drawing.Size(43, 23);
            this.izm.TabIndex = 3;
            this.izm.Text = "Метр";
            this.izm.UseVisualStyleBackColor = true;
            this.izm.CheckedChanged += new System.EventHandler(this.izm_CheckedChanged);
            // 
            // izkm
            // 
            this.izkm.Appearance = System.Windows.Forms.Appearance.Button;
            this.izkm.AutoSize = true;
            this.izkm.Location = new System.Drawing.Point(23, 132);
            this.izkm.Name = "izkm";
            this.izkm.Size = new System.Drawing.Size(67, 23);
            this.izkm.TabIndex = 4;
            this.izkm.Text = "Километр";
            this.izkm.UseVisualStyleBackColor = true;
            this.izkm.CheckedChanged += new System.EventHandler(this.izkm_CheckedChanged);
            // 
            // vkm
            // 
            this.vkm.Appearance = System.Windows.Forms.Appearance.Button;
            this.vkm.AutoSize = true;
            this.vkm.Location = new System.Drawing.Point(167, 132);
            this.vkm.Name = "vkm";
            this.vkm.Size = new System.Drawing.Size(67, 23);
            this.vkm.TabIndex = 9;
            this.vkm.Text = "Километр";
            this.vkm.UseVisualStyleBackColor = true;
            this.vkm.CheckedChanged += new System.EventHandler(this.vkm_CheckedChanged);
            // 
            // vm
            // 
            this.vm.Appearance = System.Windows.Forms.Appearance.Button;
            this.vm.AutoSize = true;
            this.vm.Location = new System.Drawing.Point(167, 109);
            this.vm.Name = "vm";
            this.vm.Size = new System.Drawing.Size(43, 23);
            this.vm.TabIndex = 8;
            this.vm.Text = "Метр";
            this.vm.UseVisualStyleBackColor = true;
            this.vm.CheckedChanged += new System.EventHandler(this.vm_CheckedChanged);
            // 
            // vdc
            // 
            this.vdc.Appearance = System.Windows.Forms.Appearance.Button;
            this.vdc.AutoSize = true;
            this.vdc.Location = new System.Drawing.Point(167, 86);
            this.vdc.Name = "vdc";
            this.vdc.Size = new System.Drawing.Size(69, 23);
            this.vdc.TabIndex = 7;
            this.vdc.Text = "Дециметр";
            this.vdc.UseVisualStyleBackColor = true;
            this.vdc.CheckedChanged += new System.EventHandler(this.vdc_CheckedChanged);
            // 
            // vsm
            // 
            this.vsm.Appearance = System.Windows.Forms.Appearance.Button;
            this.vsm.AutoSize = true;
            this.vsm.Location = new System.Drawing.Point(167, 63);
            this.vsm.Name = "vsm";
            this.vsm.Size = new System.Drawing.Size(72, 23);
            this.vsm.TabIndex = 6;
            this.vsm.Text = "Сантиметр";
            this.vsm.UseVisualStyleBackColor = true;
            this.vsm.CheckedChanged += new System.EventHandler(this.vsm_CheckedChanged);
            // 
            // vmm
            // 
            this.vmm.Appearance = System.Windows.Forms.Appearance.Button;
            this.vmm.AutoSize = true;
            this.vmm.Location = new System.Drawing.Point(167, 40);
            this.vmm.Name = "vmm";
            this.vmm.Size = new System.Drawing.Size(75, 23);
            this.vmm.TabIndex = 5;
            this.vmm.Text = "Миллиметр";
            this.vmm.UseVisualStyleBackColor = true;
            this.vmm.CheckedChanged += new System.EventHandler(this.vmm_CheckedChanged);
            // 
            // izgr
            // 
            this.izgr.Appearance = System.Windows.Forms.Appearance.Button;
            this.izgr.AutoSize = true;
            this.izgr.Location = new System.Drawing.Point(23, 185);
            this.izgr.Name = "izgr";
            this.izgr.Size = new System.Drawing.Size(51, 23);
            this.izgr.TabIndex = 10;
            this.izgr.Text = "Грамм";
            this.izgr.UseVisualStyleBackColor = true;
            this.izgr.CheckedChanged += new System.EventHandler(this.izgr_CheckedChanged);
            // 
            // izkg
            // 
            this.izkg.Appearance = System.Windows.Forms.Appearance.Button;
            this.izkg.AutoSize = true;
            this.izkg.Location = new System.Drawing.Point(23, 208);
            this.izkg.Name = "izkg";
            this.izkg.Size = new System.Drawing.Size(75, 23);
            this.izkg.TabIndex = 11;
            this.izkg.Text = "Килограмм";
            this.izkg.UseVisualStyleBackColor = true;
            this.izkg.CheckedChanged += new System.EventHandler(this.izkg_CheckedChanged);
            // 
            // izct
            // 
            this.izct.Appearance = System.Windows.Forms.Appearance.Button;
            this.izct.AutoSize = true;
            this.izct.Location = new System.Drawing.Point(23, 231);
            this.izct.Name = "izct";
            this.izct.Size = new System.Drawing.Size(60, 23);
            this.izct.TabIndex = 12;
            this.izct.Text = "Центнер";
            this.izct.UseVisualStyleBackColor = true;
            this.izct.CheckedChanged += new System.EventHandler(this.izct_CheckedChanged);
            // 
            // izt
            // 
            this.izt.Appearance = System.Windows.Forms.Appearance.Button;
            this.izt.AutoSize = true;
            this.izt.Location = new System.Drawing.Point(23, 254);
            this.izt.Name = "izt";
            this.izt.Size = new System.Drawing.Size(48, 23);
            this.izt.TabIndex = 13;
            this.izt.Text = "Тонна";
            this.izt.UseVisualStyleBackColor = true;
            this.izt.CheckedChanged += new System.EventHandler(this.izt_CheckedChanged);
            // 
            // vt
            // 
            this.vt.Appearance = System.Windows.Forms.Appearance.Button;
            this.vt.AutoSize = true;
            this.vt.Location = new System.Drawing.Point(167, 254);
            this.vt.Name = "vt";
            this.vt.Size = new System.Drawing.Size(48, 23);
            this.vt.TabIndex = 17;
            this.vt.Text = "Тонна";
            this.vt.UseVisualStyleBackColor = true;
            this.vt.CheckedChanged += new System.EventHandler(this.vt_CheckedChanged);
            // 
            // vct
            // 
            this.vct.Appearance = System.Windows.Forms.Appearance.Button;
            this.vct.AutoSize = true;
            this.vct.Location = new System.Drawing.Point(167, 231);
            this.vct.Name = "vct";
            this.vct.Size = new System.Drawing.Size(60, 23);
            this.vct.TabIndex = 16;
            this.vct.Text = "Центнер";
            this.vct.UseVisualStyleBackColor = true;
            this.vct.CheckedChanged += new System.EventHandler(this.vct_CheckedChanged);
            // 
            // vkg
            // 
            this.vkg.Appearance = System.Windows.Forms.Appearance.Button;
            this.vkg.AutoSize = true;
            this.vkg.Location = new System.Drawing.Point(167, 208);
            this.vkg.Name = "vkg";
            this.vkg.Size = new System.Drawing.Size(75, 23);
            this.vkg.TabIndex = 15;
            this.vkg.Text = "Килограмм";
            this.vkg.UseVisualStyleBackColor = true;
            this.vkg.CheckedChanged += new System.EventHandler(this.vkg_CheckedChanged);
            // 
            // vgr
            // 
            this.vgr.Appearance = System.Windows.Forms.Appearance.Button;
            this.vgr.AutoSize = true;
            this.vgr.Location = new System.Drawing.Point(167, 185);
            this.vgr.Name = "vgr";
            this.vgr.Size = new System.Drawing.Size(51, 23);
            this.vgr.TabIndex = 14;
            this.vgr.Text = "Грамм";
            this.vgr.UseVisualStyleBackColor = true;
            this.vgr.CheckedChanged += new System.EventHandler(this.vgr_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Перевод из";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(158, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Перевод в";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(58, 288);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(7, 340);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Просчитать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(170, 340);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 22;
            this.button2.Text = "Выход";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 291);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 23;
            this.label3.Text = "Ввод";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 314);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "Вывод";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(58, 311);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 24;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(164, 291);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 13);
            this.label5.TabIndex = 26;
            this.label5.Text = "Жми на перевод из";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(164, 314);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 13);
            this.label6.TabIndex = 27;
            this.label6.Text = "Жми на перевод из";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 369);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.vt);
            this.Controls.Add(this.vct);
            this.Controls.Add(this.vkg);
            this.Controls.Add(this.vgr);
            this.Controls.Add(this.izt);
            this.Controls.Add(this.izct);
            this.Controls.Add(this.izkg);
            this.Controls.Add(this.izgr);
            this.Controls.Add(this.vkm);
            this.Controls.Add(this.vm);
            this.Controls.Add(this.vdc);
            this.Controls.Add(this.vsm);
            this.Controls.Add(this.vmm);
            this.Controls.Add(this.izkm);
            this.Controls.Add(this.izm);
            this.Controls.Add(this.izdc);
            this.Controls.Add(this.izsm);
            this.Controls.Add(this.izmm);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton izmm;
        private System.Windows.Forms.RadioButton izsm;
        private System.Windows.Forms.RadioButton izdc;
        private System.Windows.Forms.RadioButton izm;
        private System.Windows.Forms.RadioButton izkm;
        private System.Windows.Forms.RadioButton vkm;
        private System.Windows.Forms.RadioButton vm;
        private System.Windows.Forms.RadioButton vdc;
        private System.Windows.Forms.RadioButton vsm;
        private System.Windows.Forms.RadioButton vmm;
        private System.Windows.Forms.RadioButton izgr;
        private System.Windows.Forms.RadioButton izkg;
        private System.Windows.Forms.RadioButton izct;
        private System.Windows.Forms.RadioButton izt;
        private System.Windows.Forms.RadioButton vt;
        private System.Windows.Forms.RadioButton vct;
        private System.Windows.Forms.RadioButton vkg;
        private System.Windows.Forms.RadioButton vgr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}